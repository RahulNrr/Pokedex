import React from 'react';
import Card from './Card'
import PokeInfo from './PokeInfo'
import axios from 'axios'
import {useState, useEffect} from "react";
const Main = ({results}) =>{
    // const url = "";
    const [text, setText] = useState("")
    const [pokeData, setPokeData] = useState([])
    const [loading, setLoading] = useState(true);
    const [url, setUrl] = useState("https://pokeapi.co/api/v2/pokemon/");
    const [pokeDex, setPokeDex] = useState();
    
    const handleApiChange = (e) =>{
        e.preventDefault();
        setText(e.target.value)
        if(text.length>0){
              results.filter((data) =>{
                let regex = new RegExp(`${text}`, 'gi')
                return data.url.match(regex)
            })
        }
      }
    const pokeFun = async()=>{
         setLoading(true);
         const res = await axios.get(url);
         console.log(res.data.results)
         getPokemon(res.data.results);
         setLoading(false);
    }
    const getPokemon = async(res) =>{
       res.map(async(item)=>{
            const results =await axios.get(item.url)
                console.log(results.data)
                setPokeData(state=>{
                    state = [...state,results.data]
                    state.sort((a,b)=>a.id-b.id)
                    return state;
              })
        })
    }
    useEffect(()=>{
      pokeFun();
    //   setUrl();
    },[url])
    return(
        <>
        <div>
        <form style={{marginTop: '10px'}} className="d-flex">
        <input className="form-control me-2" type="search" value={text} onChange={handleApiChange} placeholder="Search" aria-label="Search"/>
        <button className="btn-group" type="submit">Search</button>
        </form>
    </div>
            <div className = "container">
                <div className="left-content">
                <Card pokemon={pokeData} loading={loading} infoPokemon={poke=>setPokeDex(poke)}/>
                <div className="btn-group">
                </div>
                </div>
                <div className = "right-content">
                   <PokeInfo data={pokeDex}/>
                </div>
            </div>
        </>
    )
}
export default Main;