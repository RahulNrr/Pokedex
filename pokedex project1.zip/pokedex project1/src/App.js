import React from 'react';
import './components/Style.css';
import Main from './components/Main'
const App = () =>{
  return (
<>
  <Main/>
</>
  )
}
export default App;